import pygame
from pygame.sprite import Sprite
from screen_size import *

class pipes(Sprite):
    def __init__(self, x , y , flipped,gap):
        super(pipes,self).__init__()
        self.image = pygame.image.load('jetpack/onePipe.png')
        self.rect = self.image.get_rect()
        if flipped == 1:
            #flip the image False in x axis and True in y axis
            self.image = pygame.transform.flip(self.image,False,True)
            self.rect.bottomleft = [x,y - gap //2]
        elif flipped == -1:
            self.rect.topleft = [x,y + gap //2]

    def update(self,scroll_speed,losing):
        if losing == False:
            self.rect.x -= scroll_speed
            if self.rect.right < 0:
                self.kill()

