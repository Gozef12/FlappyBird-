import pygame.mouse



class Restart():
    def __init__(self,x,y,img):
        self.image = img
        self.rect = self.image.get_rect()
        self.rect.topleft = (x,y)
    def draw(self,screen):
        restart_action = False
        #get the mouse position
        mouse_position = pygame.mouse.get_pos()

        #checks if mouse is hovering the button

        if self.rect.collidepoint(mouse_position) and pygame.mouse.get_pressed()[0] == 1:
            restart_action = True

        screen.blit(self.image,(self.rect.x,self.rect.y))

        return restart_action





