#Name:yousef alkaiyat
#ID: 147008





import pygame
from pygame.locals import *
from sys import exit
from screen_size import *
from bird import *
import random
import math
from pygame.sprite import Sprite
from pipe import *
from score_text import *
from restart import *



pygame.init()

# restart function
def reset_fun():
    p_group.empty()
    bird.rect.x = width//4-100
    bird.rect.y = height//2
    score = 0
    return score


#load and apply bg sound

bg_music = pygame.mixer.Sound('jetpack/Flappy Bird Theme Song.mp3')
bg_music.play(loops = -1)




screen = pygame.display.set_mode((width,height))
screen_rect = screen.get_rect()
pygame.display.set_caption('WING JUMP')

bg = pygame.image.load('jetpack/bg.png').convert()
ground = pygame.image.load('jetpack/ground.png').convert()
ground_rect = ground.get_rect()

restart = pygame.image.load('jetpack/restart_btn.png')

#text properties

font = pygame.font.SysFont('Bauhaus 93', 60)
color = (255,255,255)

#star text properties
font1 = pygame.font.SysFont('Bauhaus 93', 20)
color1 = (0,0,0)



#define variables
clock =pygame.time.Clock()
fps = 60
losing = False
start =False
scroll = 0
scroll_speed = 5
gap = 150
score = 0
inPosition =False
start_text = 'Press left mouse button to start'



#the time is needed to generate new pipe
time_for_generation = 1000




#creating scrool bg
bg_width = bg.get_width()
tiles = math.ceil(width/bg_width)+1



#create bird class
bird = Bird(width//4-100,height//2)
birds = pygame.sprite.Group()
birds.add(bird)



p_group = pygame.sprite.Group()


button = Restart(width//3+50,height//2,restart)






while True:
    clock.tick(fps)
    for i in range(tiles):
     screen.blit(bg, (i*bg_width+scroll, 0))

    birds.draw(screen)
    birds.update(losing, start)
    p_group.draw(screen)
    p_group.update(scroll_speed,losing)

    #creating scrolling bg
    for i in range(tiles):
     
     screen.blit(ground,(i*bg_width+scroll,700))


    #scoring

    if len(p_group) > 0:
        if birds.sprites()[0].rect.left > p_group.sprites()[0].rect.left and birds.sprites()[0].rect.right < p_group.sprites()[0].rect.right and inPosition == False:
            inPosition = True
        if inPosition == True and birds.sprites()[0].rect.left > p_group.sprites()[0].rect.right:
            score+=1
            inPosition = False

    drawText(str(score), font, color, width // 2, 10, screen)


    if losing == False :
        #generating the new pipes
        time_for_generation -=10
        if time_for_generation == 0 and start ==True:
            # create pipe class
            gap_height = random.randint(-250, 150)
            top_p = pipes(width, height // 2 + gap_height, -1, gap)
            bottom_p = pipes(width, height // 2 + gap_height, 1, gap)
            p_group.add(top_p)
            p_group.add(bottom_p)
            time_for_generation =1000

#scrollin the images
        scroll -=scroll_speed
        if abs(scroll) > bg_width:
            scroll =0
                                    #it was set to false because if it were true the object will be deleted
    if pygame.sprite.groupcollide(birds,p_group,False,False) or bird.rect.top <0:
        losing = True



    if bird.rect.bottom >= 700:
        losing = True
        start = False



    #checks if he lost then display the restart image
    if losing == True:
        if button.draw(screen):
            losing = False
            score = reset_fun()

    if start == False and losing == False:
        drawText(start_text, font1, color1, width // 4, height//2, screen)



    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
        if event.type == MOUSEBUTTONDOWN and start == False:
            start = True







    pygame.display.update()
