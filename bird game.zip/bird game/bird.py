import pygame
from pygame.sprite import Sprite
from screen_size import *




class Bird(Sprite):

    def __init__(self,x_co,y_co):
        super(Bird,self).__init__()
        self.x_co = x_co
        self.y_co = y_co
        self.images = []
        self.index = 0
        self.counter = 0
# load different image of bird
        for i in range(1,4):
            img = pygame.image.load(f'jetpack/b{i}.png')
            self.images.append(img)

        self.image = self.images[self.index]
        self.rect = self.image.get_rect()
        self.rect.center = [x_co,y_co]
        self.falling_speed = 0
        self.click = False
        self.jump_sound = pygame.mixer.Sound('jetpack/jump.wav')
        self.jump_sound.set_volume(0.5)





    def gravity(self,start):
        # gravity
        if start == True:
            self.falling_speed += 0.2
            if self.falling_speed > 8:
                self.falling_speed = 8
            if self.rect.bottom < 700:
                self.rect.y += int(self.falling_speed)



    def jump(self,losing):
        # jumping
        if pygame.mouse.get_pressed()[0] == 1 and self.click == False and losing == False:
            self.click = True
            self.falling_speed = -5
            self.jump_sound.play()

        if pygame.mouse.get_pressed()[0] == 0 and self.click:
            self.click = False



    def animation(self,losing):
        # how fast is my animation
        if losing == False:
            self.counter += 1
            cooling = 15
            if self.counter > cooling:
                self.counter = 0
                self.index += 1
                if self.index >= len(self.images):
                    self.index = 0
                self.image = self.images[self.index]



    def rotation(self,losing):
        # rotate the image when falling
        self.image = pygame.transform.rotate(self.images[self.index], self.falling_speed * -2)
        if losing == True:
            self.image = pygame.transform.rotate(self.images[self.index],-90)



    def update(self,losing,start):
        self.gravity(start)
        self.jump(losing)
        self.animation(losing)
        self.rotation(losing)













